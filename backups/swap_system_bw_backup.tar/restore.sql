--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE swap_system_bw;
--
-- Name: swap_system_bw; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE swap_system_bw WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE swap_system_bw OWNER TO postgres;

\unrestrict (null)
\connect swap_system_bw
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: account_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.account_type AS ENUM (
    'asset',
    'liability',
    'equity',
    'revenue',
    'expense'
);


ALTER TYPE public.account_type OWNER TO postgres;

--
-- Name: fraud_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.fraud_status AS ENUM (
    'unchecked',
    'passed',
    'failed',
    'manual_review'
);


ALTER TYPE public.fraud_status OWNER TO postgres;

--
-- Name: kyc_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.kyc_status AS ENUM (
    'pending',
    'approved',
    'rejected',
    'expired'
);


ALTER TYPE public.kyc_status OWNER TO postgres;

--
-- Name: ledger_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.ledger_type AS ENUM (
    'customer',
    'escrow',
    'treasury',
    'fee',
    'settlement'
);


ALTER TYPE public.ledger_type OWNER TO postgres;

--
-- Name: swap_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.swap_status AS ENUM (
    'pending',
    'processing',
    'completed',
    'failed',
    'cancelled'
);


ALTER TYPE public.swap_status OWNER TO postgres;

--
-- Name: fn_update_timestamp(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_update_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.fn_update_timestamp() OWNER TO postgres;

--
-- Name: load_participants_from_json(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.load_participants_from_json(json_file_path text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
    json_content TEXT;
    json_data JSONB;
    participant_key TEXT;
    participant_data JSONB;
    inserted_count INT := 0;
    updated_count INT := 0;
BEGIN
    -- Read the JSON file
    BEGIN
        json_content := pg_read_file(json_file_path, 0, 1000000);
    EXCEPTION WHEN OTHERS THEN
        RETURN 'Error reading file: ' || SQLERRM;
    END;
    
    -- Parse JSON
    BEGIN
        json_data := json_content::JSONB;
    EXCEPTION WHEN OTHERS THEN
        RETURN 'Error parsing JSON: ' || SQLERRM;
    END;
    
    -- Check if it has the expected structure
    IF json_data ? 'participants' THEN
        -- Loop through each participant
        FOR participant_key, participant_data IN SELECT * FROM jsonb_each(json_data->'participants')
        LOOP
            INSERT INTO participants (
                name,
                type,
                category,
                provider_code,
                auth_type,
                base_url,
                system_user_id,
                legal_entity_identifier,
                license_number,
                settlement_account,
                settlement_type,
                status,
                capabilities,
                resource_endpoints,
                phone_format,
                security_config,
                message_profile,
                routing_info
            ) VALUES (
                participant_key,
                participant_data->>'type',
                participant_data->>'category',
                participant_data->>'provider_code',
                participant_data->>'auth_type',
                participant_data->>'base_url',
                (participant_data->'identity'->>'system_user_id')::BIGINT,
                participant_data->'identity'->>'legal_entity_identifier',
                participant_data->'identity'->>'license_number',
                participant_data->'routing'->>'settlement_account',
                participant_data->'routing'->>'settlement_type',
                COALESCE(participant_data->>'status', 'ACTIVE'),
                participant_data->'capabilities',
                participant_data->'resource_endpoints',
                participant_data->'phone_format',
                participant_data->'security',
                participant_data->'message_profile',
                participant_data->'routing'
            )
            ON CONFLICT (name) DO UPDATE SET
                type = EXCLUDED.type,
                category = EXCLUDED.category,
                provider_code = EXCLUDED.provider_code,
                auth_type = EXCLUDED.auth_type,
                base_url = EXCLUDED.base_url,
                system_user_id = EXCLUDED.system_user_id,
                legal_entity_identifier = EXCLUDED.legal_entity_identifier,
                license_number = EXCLUDED.license_number,
                settlement_account = EXCLUDED.settlement_account,
                settlement_type = EXCLUDED.settlement_type,
                status = EXCLUDED.status,
                capabilities = EXCLUDED.capabilities,
                resource_endpoints = EXCLUDED.resource_endpoints,
                phone_format = EXCLUDED.phone_format,
                security_config = EXCLUDED.security_config,
                message_profile = EXCLUDED.message_profile,
                routing_info = EXCLUDED.routing_info,
                updated_at = CURRENT_TIMESTAMP;
                
            GET DIAGNOSTICS updated_count = ROW_COUNT;
            IF updated_count > 0 THEN
                inserted_count := inserted_count + 1;
            END IF;
        END LOOP;
        
        RETURN format('Loaded/Updated %s participants successfully.', inserted_count);
    ELSE
        RETURN 'Invalid JSON format: missing "participants" key';
    END IF;
END;
$$;


ALTER FUNCTION public.load_participants_from_json(json_file_path text) OWNER TO postgres;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: vouchmorphn_user
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO vouchmorphn_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admins; Type: TABLE; Schema: public; Owner: vouchmorphn_user
--

CREATE TABLE public.admins (
    admin_id bigint NOT NULL,
    username character varying(100) NOT NULL,
    email character varying(150) NOT NULL,
    phone character varying(20),
    password_hash character varying(255) NOT NULL,
    role_id bigint,
    mfa_enabled boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.admins OWNER TO vouchmorphn_user;

--
-- Name: admins_admin_id_seq; Type: SEQUENCE; Schema: public; Owner: vouchmorphn_user
--

CREATE SEQUENCE public.admins_admin_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admins_admin_id_seq OWNER TO vouchmorphn_user;

--
-- Name: admins_admin_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vouchmorphn_user
--

ALTER SEQUENCE public.admins_admin_id_seq OWNED BY public.admins.admin_id;


--
-- Name: aml_checks; Type: TABLE; Schema: public; Owner: vouchmorphn_user
--

CREATE TABLE public.aml_checks (
    check_id bigint NOT NULL,
    user_id bigint,
    check_type character varying(50),
    check_reference character varying(255),
    risk_score numeric(5,2),
    status character varying(20) DEFAULT 'pending'::character varying,
    findings jsonb,
    performed_by character varying(100),
    performed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    expiry_date timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.aml_checks OWNER TO vouchmorphn_user;

--
-- Name: aml_checks_check_id_seq; Type: SEQUENCE; Schema: public; Owner: vouchmorphn_user
--

CREATE SEQUENCE public.aml_checks_check_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.aml_checks_check_id_seq OWNER TO vouchmorphn_user;

--
-- Name: aml_checks_check_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vouchmorphn_user
--

ALTER SEQUENCE public.aml_checks_check_id_seq OWNED BY public.aml_checks.check_id;


--
-- Name: api_message_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_message_logs (
    log_id bigint NOT NULL,
    message_id character varying(100) NOT NULL,
    message_type character varying(50) NOT NULL,
    direction character varying(10) NOT NULL,
    participant_id bigint,
    participant_name character varying(100),
    endpoint character varying(255),
    request_payload jsonb,
    response_payload jsonb,
    http_status_code integer,
    curl_error text,
    success boolean DEFAULT false,
    duration_ms integer,
    retry_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    processed_at timestamp with time zone
);


ALTER TABLE public.api_message_logs OWNER TO postgres;

--
-- Name: api_message_logs_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.api_message_logs_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.api_message_logs_log_id_seq OWNER TO postgres;

--
-- Name: api_message_logs_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.api_message_logs_log_id_seq OWNED BY public.api_message_logs.log_id;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: vouchmorphn_user
--

CREATE TABLE public.audit_logs (
    audit_id bigint NOT NULL,
    audit_uuid uuid DEFAULT gen_random_uuid(),
    entity_type character varying(50),
    entity_id bigint,
    action character varying(50),
    category character varying(50),
    severity character varying(20) DEFAULT 'info'::character varying,
    old_value jsonb,
    new_value jsonb,
    changes jsonb,
    performed_by_type character varying(20),
    performed_by_id bigint,
    ip_address inet,
    user_agent text,
    geo_location jsonb,
    request_id character varying(100),
    performed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT audit_logs_performed_by_type_check CHECK (((performed_by_type)::text = ANY ((ARRAY['user'::character varying, 'admin'::character varying, 'system'::character varying])::text[]))),
    CONSTRAINT audit_logs_severity_check CHECK (((severity)::text = ANY ((ARRAY['info'::character varying, 'warning'::character varying, 'error'::character varying, 'critical'::character varying])::text[])))
);


ALTER TABLE public.audit_logs OWNER TO vouchmorphn_user;

--
-- Name: audit_logs_audit_id_seq; Type: SEQUENCE; Schema: public; Owner: vouchmorphn_user
--

CREATE SEQUENCE public.audit_logs_audit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_logs_audit_id_seq OWNER TO vouchmorphn_user;

--
-- Name: audit_logs_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vouchmorphn_user
--

ALTER SEQUENCE public.audit_logs_audit_id_seq OWNED BY public.audit_logs.audit_id;


--
-- Name: cashout_authorizations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cashout_authorizations (
    auth_id bigint NOT NULL,
    swap_reference character varying(100) NOT NULL,
    client_phone character varying(20) NOT NULL,
    source_institution character varying(100) NOT NULL,
    source_wallet character varying(100) NOT NULL,
    amount numeric(20,2) NOT NULL,
    currency character(3) DEFAULT 'BWP'::bpchar NOT NULL,
    fee_amount numeric(20,2) DEFAULT 0.00,
    swap_code character varying(50),
    pin_code character varying(10),
    code_expiry timestamp with time zone,
    cashout_point character varying(50) NOT NULL,
    cashout_provider character varying(100),
    status character varying(50) DEFAULT 'PENDING'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone,
    code_used_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.cashout_authorizations OWNER TO postgres;

--
-- Name: cashout_authorizations_auth_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cashout_authorizations_auth_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cashout_authorizations_auth_id_seq OWNER TO postgres;

--
-- Name: cashout_authorizations_auth_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cashout_authorizations_auth_id_seq OWNED BY public.cashout_authorizations.auth_id;


--
-- Name: deposit_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.deposit_transactions (
    deposit_id bigint NOT NULL,
    transaction_reference character varying(100) NOT NULL,
    client_phone character varying(20) NOT NULL,
    source_type character varying(50) NOT NULL,
    source_institution character varying(100) NOT NULL,
    source_account character varying(100) NOT NULL,
    destination_type character varying(50) NOT NULL,
    destination_institution character varying(100),
    destination_account character varying(100),
    amount numeric(20,2) NOT NULL,
    currency character(3) DEFAULT 'BWP'::bpchar NOT NULL,
    fee_amount numeric(20,2) DEFAULT 0.00,
    status character varying(50) DEFAULT 'PENDING'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb,
    CONSTRAINT deposit_transactions_amount_check CHECK ((amount > (0)::numeric))
);


ALTER TABLE public.deposit_transactions OWNER TO postgres;

--
-- Name: deposit_transactions_deposit_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.deposit_transactions_deposit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.deposit_transactions_deposit_id_seq OWNER TO postgres;

--
-- Name: deposit_transactions_deposit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.deposit_transactions_deposit_id_seq OWNED BY public.deposit_transactions.deposit_id;


--
-- Name: hold_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.hold_transactions (
    hold_id bigint NOT NULL,
    hold_reference character varying(100) NOT NULL,
    swap_reference character varying(100) NOT NULL,
    participant_id bigint,
    participant_name character varying(100),
    asset_type character varying(50) NOT NULL,
    amount numeric(20,8) NOT NULL,
    currency character(3) DEFAULT 'BWP'::bpchar,
    status character varying(20) DEFAULT 'ACTIVE'::character varying,
    hold_expiry timestamp with time zone,
    source_details jsonb,
    destination_institution character varying(100),
    destination_participant_id bigint,
    metadata jsonb,
    placed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    released_at timestamp with time zone,
    debited_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.hold_transactions OWNER TO postgres;

--
-- Name: hold_transactions_hold_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.hold_transactions_hold_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.hold_transactions_hold_id_seq OWNER TO postgres;

--
-- Name: hold_transactions_hold_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.hold_transactions_hold_id_seq OWNED BY public.hold_transactions.hold_id;


--
-- Name: kyc_documents; Type: TABLE; Schema: public; Owner: vouchmorphn_user
--

CREATE TABLE public.kyc_documents (
    kyc_id bigint NOT NULL,
    user_id bigint,
    document_type character varying(50),
    document_number character varying(100),
    status public.kyc_status DEFAULT 'pending'::public.kyc_status,
    document_path character varying(255),
    document_hash character varying(255),
    expiry_date date,
    admin_reviewer_id bigint,
    review_date timestamp with time zone,
    review_notes text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT kyc_documents_document_type_check CHECK (((document_type)::text = ANY ((ARRAY['passport'::character varying, 'national_id'::character varying, 'drivers_license'::character varying, 'utility_bill'::character varying, 'bank_statement'::character varying])::text[])))
);


ALTER TABLE public.kyc_documents OWNER TO vouchmorphn_user;

--
-- Name: kyc_documents_kyc_id_seq; Type: SEQUENCE; Schema: public; Owner: vouchmorphn_user
--

CREATE SEQUENCE public.kyc_documents_kyc_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.kyc_documents_kyc_id_seq OWNER TO vouchmorphn_user;

--
-- Name: kyc_documents_kyc_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vouchmorphn_user
--

ALTER SEQUENCE public.kyc_documents_kyc_id_seq OWNED BY public.kyc_documents.kyc_id;


--
-- Name: ledger_accounts; Type: TABLE; Schema: public; Owner: vouchmorphn_user
--

CREATE TABLE public.ledger_accounts (
    account_id bigint NOT NULL,
    account_code character varying(20),
    account_name character varying(100) NOT NULL,
    account_type public.ledger_type NOT NULL,
    balance numeric(20,8) DEFAULT 0,
    participant_id bigint,
    currency_code character(3) DEFAULT 'BWP'::bpchar,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.ledger_accounts OWNER TO vouchmorphn_user;

--
-- Name: ledger_accounts_account_id_seq; Type: SEQUENCE; Schema: public; Owner: vouchmorphn_user
--

CREATE SEQUENCE public.ledger_accounts_account_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ledger_accounts_account_id_seq OWNER TO vouchmorphn_user;

--
-- Name: ledger_accounts_account_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vouchmorphn_user
--

ALTER SEQUENCE public.ledger_accounts_account_id_seq OWNED BY public.ledger_accounts.account_id;


--
-- Name: ledger_entries; Type: TABLE; Schema: public; Owner: vouchmorphn_user
--

CREATE TABLE public.ledger_entries (
    entry_id bigint NOT NULL,
    transaction_id bigint,
    debit_account_id bigint,
    credit_account_id bigint,
    amount numeric(20,8) NOT NULL,
    currency_code character(3) DEFAULT 'BWP'::bpchar,
    reference character varying(50),
    split_type character varying(50) DEFAULT 'main'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.ledger_entries OWNER TO vouchmorphn_user;

--
-- Name: ledger_entries_entry_id_seq; Type: SEQUENCE; Schema: public; Owner: vouchmorphn_user
--

CREATE SEQUENCE public.ledger_entries_entry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ledger_entries_entry_id_seq OWNER TO vouchmorphn_user;

--
-- Name: ledger_entries_entry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vouchmorphn_user
--

ALTER SEQUENCE public.ledger_entries_entry_id_seq OWNED BY public.ledger_entries.entry_id;


--
-- Name: message_outbox; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.message_outbox (
    message_id character varying(50) NOT NULL,
    channel character varying(20) NOT NULL,
    destination character varying(100) NOT NULL,
    payload jsonb NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    sent_at timestamp without time zone
);


ALTER TABLE public.message_outbox OWNER TO postgres;

--
-- Name: net_positions; Type: TABLE; Schema: public; Owner: vouchmorphn_user
--

CREATE TABLE public.net_positions (
    id bigint NOT NULL,
    debtor character varying(100) NOT NULL,
    creditor character varying(100) NOT NULL,
    amount numeric(20,8) DEFAULT 0,
    currency_code character(3) DEFAULT 'BWP'::bpchar,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.net_positions OWNER TO vouchmorphn_user;

--
-- Name: net_positions_id_seq; Type: SEQUENCE; Schema: public; Owner: vouchmorphn_user
--

CREATE SEQUENCE public.net_positions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.net_positions_id_seq OWNER TO vouchmorphn_user;

--
-- Name: net_positions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vouchmorphn_user
--

ALTER SEQUENCE public.net_positions_id_seq OWNED BY public.net_positions.id;


--
-- Name: otp_logs; Type: TABLE; Schema: public; Owner: vouchmorphn_user
--

CREATE TABLE public.otp_logs (
    otp_id bigint NOT NULL,
    identifier character varying(255) NOT NULL,
    identifier_type character varying(20),
    code_hash character varying(255) NOT NULL,
    purpose character varying(50),
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    attempts integer DEFAULT 0,
    ip_address inet,
    user_agent text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT otp_logs_identifier_type_check CHECK (((identifier_type)::text = ANY ((ARRAY['phone'::character varying, 'email'::character varying, 'user_id'::character varying])::text[]))),
    CONSTRAINT otp_logs_purpose_check CHECK (((purpose)::text = ANY ((ARRAY['login'::character varying, 'transaction'::character varying, 'kyc'::character varying, 'password_reset'::character varying, 'phone_verification'::character varying])::text[])))
);


ALTER TABLE public.otp_logs OWNER TO vouchmorphn_user;

--
-- Name: otp_logs_otp_id_seq; Type: SEQUENCE; Schema: public; Owner: vouchmorphn_user
--

CREATE SEQUENCE public.otp_logs_otp_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.otp_logs_otp_id_seq OWNER TO vouchmorphn_user;

--
-- Name: otp_logs_otp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vouchmorphn_user
--

ALTER SEQUENCE public.otp_logs_otp_id_seq OWNED BY public.otp_logs.otp_id;


--
-- Name: participant_fee_overrides; Type: TABLE; Schema: public; Owner: vouchmorphn_user
--

CREATE TABLE public.participant_fee_overrides (
    override_id bigint NOT NULL,
    participant_id bigint,
    transaction_type character varying(20),
    fee_amount numeric(12,2),
    split jsonb,
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.participant_fee_overrides OWNER TO vouchmorphn_user;

--
-- Name: participant_fee_overrides_override_id_seq; Type: SEQUENCE; Schema: public; Owner: vouchmorphn_user
--

CREATE SEQUENCE public.participant_fee_overrides_override_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.participant_fee_overrides_override_id_seq OWNER TO vouchmorphn_user;

--
-- Name: participant_fee_overrides_override_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vouchmorphn_user
--

ALTER SEQUENCE public.participant_fee_overrides_override_id_seq OWNED BY public.participant_fee_overrides.override_id;


--
-- Name: participants; Type: TABLE; Schema: public; Owner: vouchmorphn_user
--

CREATE TABLE public.participants (
    participant_id bigint NOT NULL,
    name character varying(100) NOT NULL,
    type character varying(50),
    category character varying(50),
    provider_code character varying(50),
    auth_type character varying(50),
    base_url text,
    system_user_id bigint,
    legal_entity_identifier character varying(50),
    license_number character varying(50),
    settlement_account character varying(50),
    settlement_type character varying(50),
    status character varying(20),
    capabilities jsonb,
    resource_endpoints jsonb,
    phone_format jsonb,
    security_config jsonb,
    message_profile jsonb,
    routing_info jsonb,
    metadata jsonb
);


ALTER TABLE public.participants OWNER TO vouchmorphn_user;

--
-- Name: participants_participant_id_seq; Type: SEQUENCE; Schema: public; Owner: vouchmorphn_user
--

CREATE SEQUENCE public.participants_participant_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.participants_participant_id_seq OWNER TO vouchmorphn_user;

--
-- Name: participants_participant_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vouchmorphn_user
--

ALTER SEQUENCE public.participants_participant_id_seq OWNED BY public.participants.participant_id;


--
-- Name: regulator_outbox; Type: TABLE; Schema: public; Owner: vouchmorphn_user
--

CREATE TABLE public.regulator_outbox (
    id integer NOT NULL,
    report_id text NOT NULL,
    payload jsonb NOT NULL,
    integrity_hash text NOT NULL,
    status text NOT NULL,
    attempts integer DEFAULT 0,
    last_attempt timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.regulator_outbox OWNER TO vouchmorphn_user;

--
-- Name: regulator_outbox_id_seq; Type: SEQUENCE; Schema: public; Owner: vouchmorphn_user
--

CREATE SEQUENCE public.regulator_outbox_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.regulator_outbox_id_seq OWNER TO vouchmorphn_user;

--
-- Name: regulator_outbox_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vouchmorphn_user
--

ALTER SEQUENCE public.regulator_outbox_id_seq OWNED BY public.regulator_outbox.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: vouchmorphn_user
--

CREATE TABLE public.roles (
    role_id bigint NOT NULL,
    role_name character varying(50) NOT NULL,
    description text,
    permissions jsonb DEFAULT '[]'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT role_name_check CHECK (((role_name)::text = ANY ((ARRAY['user'::character varying, 'admin'::character varying, 'compliance'::character varying, 'auditor'::character varying, 'super_admin'::character varying])::text[])))
);


ALTER TABLE public.roles OWNER TO vouchmorphn_user;

--
-- Name: roles_role_id_seq; Type: SEQUENCE; Schema: public; Owner: vouchmorphn_user
--

CREATE SEQUENCE public.roles_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_role_id_seq OWNER TO vouchmorphn_user;

--
-- Name: roles_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vouchmorphn_user
--

ALTER SEQUENCE public.roles_role_id_seq OWNED BY public.roles.role_id;


--
-- Name: sandbox_disclosures; Type: TABLE; Schema: public; Owner: vouchmorphn_user
--

CREATE TABLE public.sandbox_disclosures (
    id integer NOT NULL,
    user_id bigint,
    consent_version character varying(10),
    has_accepted boolean DEFAULT false,
    disclosure_text text,
    experimental_risk_acknowledged_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.sandbox_disclosures OWNER TO vouchmorphn_user;

--
-- Name: sandbox_disclosures_id_seq; Type: SEQUENCE; Schema: public; Owner: vouchmorphn_user
--

CREATE SEQUENCE public.sandbox_disclosures_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sandbox_disclosures_id_seq OWNER TO vouchmorphn_user;

--
-- Name: sandbox_disclosures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vouchmorphn_user
--

ALTER SEQUENCE public.sandbox_disclosures_id_seq OWNED BY public.sandbox_disclosures.id;


--
-- Name: send_to_other_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.send_to_other_transactions (
    send_id bigint NOT NULL,
    transaction_reference character varying(100) NOT NULL,
    sender_phone character varying(20) NOT NULL,
    sender_institution character varying(100) NOT NULL,
    sender_account character varying(100) NOT NULL,
    receiver_phone character varying(20) NOT NULL,
    receiver_institution character varying(100) NOT NULL,
    receiver_account character varying(100) NOT NULL,
    amount numeric(20,2) NOT NULL,
    currency character(3) DEFAULT 'BWP'::bpchar NOT NULL,
    fee_amount numeric(20,2) DEFAULT 0.00,
    status character varying(50) DEFAULT 'PENDING'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone,
    notification_sent boolean DEFAULT false,
    metadata jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.send_to_other_transactions OWNER TO postgres;

--
-- Name: send_to_other_transactions_send_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.send_to_other_transactions_send_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.send_to_other_transactions_send_id_seq OWNER TO postgres;

--
-- Name: send_to_other_transactions_send_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.send_to_other_transactions_send_id_seq OWNED BY public.send_to_other_transactions.send_id;


--
-- Name: settlement_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.settlement_messages (
    message_id integer NOT NULL,
    transaction_id character varying(64) NOT NULL,
    from_participant character varying(50) NOT NULL,
    to_participant character varying(50) NOT NULL,
    amount numeric(15,2) NOT NULL,
    type character varying(50) NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    processed_at timestamp without time zone
);


ALTER TABLE public.settlement_messages OWNER TO postgres;

--
-- Name: settlement_messages_message_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.settlement_messages_message_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.settlement_messages_message_id_seq OWNER TO postgres;

--
-- Name: settlement_messages_message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.settlement_messages_message_id_seq OWNED BY public.settlement_messages.message_id;


--
-- Name: settlement_queue; Type: TABLE; Schema: public; Owner: vouchmorphn_user
--

CREATE TABLE public.settlement_queue (
    id bigint NOT NULL,
    debtor character varying(100) NOT NULL,
    creditor character varying(100) NOT NULL,
    amount numeric(20,8) DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.settlement_queue OWNER TO vouchmorphn_user;

--
-- Name: settlement_queue_id_seq; Type: SEQUENCE; Schema: public; Owner: vouchmorphn_user
--

CREATE SEQUENCE public.settlement_queue_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.settlement_queue_id_seq OWNER TO vouchmorphn_user;

--
-- Name: settlement_queue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vouchmorphn_user
--

ALTER SEQUENCE public.settlement_queue_id_seq OWNED BY public.settlement_queue.id;


--
-- Name: supervisory_heartbeat; Type: TABLE; Schema: public; Owner: vouchmorphn_user
--

CREATE TABLE public.supervisory_heartbeat (
    heartbeat_id integer NOT NULL,
    status character varying(20) DEFAULT 'ACTIVE'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    latency_ms integer DEFAULT 0,
    system_load numeric(5,2) DEFAULT 0
);


ALTER TABLE public.supervisory_heartbeat OWNER TO vouchmorphn_user;

--
-- Name: supervisory_heartbeat_heartbeat_id_seq; Type: SEQUENCE; Schema: public; Owner: vouchmorphn_user
--

CREATE SEQUENCE public.supervisory_heartbeat_heartbeat_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.supervisory_heartbeat_heartbeat_id_seq OWNER TO vouchmorphn_user;

--
-- Name: supervisory_heartbeat_heartbeat_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vouchmorphn_user
--

ALTER SEQUENCE public.supervisory_heartbeat_heartbeat_id_seq OWNED BY public.supervisory_heartbeat.heartbeat_id;


--
-- Name: swap_fee_collections; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.swap_fee_collections (
    fee_id bigint NOT NULL,
    swap_reference character varying(100) NOT NULL,
    fee_type character varying(20) NOT NULL,
    total_amount numeric(20,8) NOT NULL,
    currency character(3) DEFAULT 'BWP'::bpchar,
    source_institution character varying(100) NOT NULL,
    destination_institution character varying(100) NOT NULL,
    split_config jsonb NOT NULL,
    vat_amount numeric(20,8) DEFAULT 0,
    status character varying(20) DEFAULT 'COLLECTED'::character varying,
    collected_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    settled_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.swap_fee_collections OWNER TO postgres;

--
-- Name: swap_fee_collections_fee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.swap_fee_collections_fee_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.swap_fee_collections_fee_id_seq OWNER TO postgres;

--
-- Name: swap_fee_collections_fee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.swap_fee_collections_fee_id_seq OWNED BY public.swap_fee_collections.fee_id;


--
-- Name: swap_ledgers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.swap_ledgers (
    ledger_id integer NOT NULL,
    swap_reference character varying(64) NOT NULL,
    from_institution character varying(50) NOT NULL,
    to_institution character varying(50) NOT NULL,
    amount numeric(15,2) NOT NULL,
    currency_code character varying(3) NOT NULL,
    swap_fee numeric(15,2) NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.swap_ledgers OWNER TO postgres;

--
-- Name: swap_ledgers_ledger_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.swap_ledgers_ledger_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.swap_ledgers_ledger_id_seq OWNER TO postgres;

--
-- Name: swap_ledgers_ledger_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.swap_ledgers_ledger_id_seq OWNED BY public.swap_ledgers.ledger_id;


--
-- Name: swap_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.swap_requests (
    swap_id integer NOT NULL,
    swap_uuid character varying(100) NOT NULL,
    from_currency character varying(3) NOT NULL,
    to_currency character varying(3) NOT NULL,
    amount numeric(15,2) NOT NULL,
    source_details jsonb NOT NULL,
    destination_details jsonb NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.swap_requests OWNER TO postgres;

--
-- Name: swap_requests_swap_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.swap_requests_swap_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.swap_requests_swap_id_seq OWNER TO postgres;

--
-- Name: swap_requests_swap_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.swap_requests_swap_id_seq OWNED BY public.swap_requests.swap_id;


--
-- Name: swap_transactions; Type: TABLE; Schema: public; Owner: vouchmorphn_user
--

CREATE TABLE public.swap_transactions (
    swap_transaction_id bigint NOT NULL,
    swap_id bigint,
    transaction_id bigint,
    from_account_details jsonb NOT NULL,
    to_account_details jsonb NOT NULL,
    amount numeric(20,8) NOT NULL,
    ledger_entry_id bigint,
    settlement_batch_id bigint,
    status public.swap_status DEFAULT 'pending'::public.swap_status,
    error_message text,
    retry_count integer DEFAULT 0,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.swap_transactions OWNER TO vouchmorphn_user;

--
-- Name: swap_transactions_swap_transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: vouchmorphn_user
--

CREATE SEQUENCE public.swap_transactions_swap_transaction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.swap_transactions_swap_transaction_id_seq OWNER TO vouchmorphn_user;

--
-- Name: swap_transactions_swap_transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vouchmorphn_user
--

ALTER SEQUENCE public.swap_transactions_swap_transaction_id_seq OWNED BY public.swap_transactions.swap_transaction_id;


--
-- Name: swap_vouchers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.swap_vouchers (
    voucher_id integer NOT NULL,
    swap_id integer,
    code_hash character varying(255) NOT NULL,
    code_suffix character varying(4) NOT NULL,
    amount numeric(15,2) NOT NULL,
    expiry_at timestamp without time zone NOT NULL,
    status character varying(20) DEFAULT 'ACTIVE'::character varying,
    claimant_phone character varying(20),
    is_cardless_redemption boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.swap_vouchers OWNER TO postgres;

--
-- Name: swap_vouchers_voucher_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.swap_vouchers_voucher_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.swap_vouchers_voucher_id_seq OWNER TO postgres;

--
-- Name: swap_vouchers_voucher_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.swap_vouchers_voucher_id_seq OWNED BY public.swap_vouchers.voucher_id;


--
-- Name: transaction_fees; Type: TABLE; Schema: public; Owner: vouchmorphn_user
--

CREATE TABLE public.transaction_fees (
    fee_id bigint NOT NULL,
    transaction_type character varying(20) NOT NULL,
    amount numeric(12,2) NOT NULL,
    currency character varying(5) DEFAULT 'BWP'::character varying,
    split_config jsonb,
    taxable boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.transaction_fees OWNER TO vouchmorphn_user;

--
-- Name: transaction_fees_fee_id_seq; Type: SEQUENCE; Schema: public; Owner: vouchmorphn_user
--

CREATE SEQUENCE public.transaction_fees_fee_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.transaction_fees_fee_id_seq OWNER TO vouchmorphn_user;

--
-- Name: transaction_fees_fee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vouchmorphn_user
--

ALTER SEQUENCE public.transaction_fees_fee_id_seq OWNED BY public.transaction_fees.fee_id;


--
-- Name: transaction_log_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.transaction_log_view AS
 SELECT COALESCE(ht.swap_reference, aml.message_id) AS transaction_id,
    ht.hold_reference,
    ht.status AS hold_status,
    ht.placed_at AS hold_placed_at,
    ht.debited_at,
    ht.amount AS hold_amount,
    ht.asset_type,
    p.name AS participant_name,
    p.provider_code,
    p.type AS participant_type,
    aml.message_type,
    aml.success AS api_success,
    aml.http_status_code,
    aml.created_at AS api_called_at,
    aml.endpoint,
    aml.direction
   FROM ((public.hold_transactions ht
     FULL JOIN public.api_message_logs aml ON (((ht.swap_reference)::text = (aml.message_id)::text)))
     LEFT JOIN public.participants p ON ((COALESCE(ht.participant_id, aml.participant_id) = p.participant_id)));


ALTER VIEW public.transaction_log_view OWNER TO postgres;

--
-- Name: transaction_splits; Type: TABLE; Schema: public; Owner: vouchmorphn_user
--

CREATE TABLE public.transaction_splits (
    split_id bigint NOT NULL,
    transaction_id bigint,
    split_type character varying(50),
    amount numeric(20,8) NOT NULL,
    currency_code character(3) DEFAULT 'BWP'::bpchar,
    credited_account bigint,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.transaction_splits OWNER TO vouchmorphn_user;

--
-- Name: transaction_splits_split_id_seq; Type: SEQUENCE; Schema: public; Owner: vouchmorphn_user
--

CREATE SEQUENCE public.transaction_splits_split_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.transaction_splits_split_id_seq OWNER TO vouchmorphn_user;

--
-- Name: transaction_splits_split_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vouchmorphn_user
--

ALTER SEQUENCE public.transaction_splits_split_id_seq OWNED BY public.transaction_splits.split_id;


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: vouchmorphn_user
--

CREATE TABLE public.transactions (
    transaction_id bigint NOT NULL,
    transaction_type character varying(50) NOT NULL,
    amount numeric(20,8) DEFAULT 0,
    fee numeric(20,8) DEFAULT 0,
    sat_purchased numeric(20,8) DEFAULT 0,
    currency_code character(3) DEFAULT 'BWP'::bpchar,
    status character varying(20) DEFAULT 'PDNG'::character varying,
    sca_required boolean DEFAULT false,
    sca_verified_at timestamp with time zone,
    reference_uuid uuid DEFAULT gen_random_uuid(),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    origin_participant_id bigint,
    destination_participant_id bigint,
    origin_name character varying(100),
    destination_name character varying(100)
);


ALTER TABLE public.transactions OWNER TO vouchmorphn_user;

--
-- Name: transactions_transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: vouchmorphn_user
--

CREATE SEQUENCE public.transactions_transaction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.transactions_transaction_id_seq OWNER TO vouchmorphn_user;

--
-- Name: transactions_transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vouchmorphn_user
--

ALTER SEQUENCE public.transactions_transaction_id_seq OWNED BY public.transactions.transaction_id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: vouchmorphn_user
--

CREATE TABLE public.users (
    user_id bigint NOT NULL,
    username character varying(100) NOT NULL,
    email character varying(150) NOT NULL,
    phone character varying(20) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role_id bigint DEFAULT 1,
    verified boolean DEFAULT false,
    kyc_verified boolean DEFAULT false,
    aml_score numeric(5,2) DEFAULT 0,
    mfa_enabled boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.users OWNER TO vouchmorphn_user;

--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: vouchmorphn_user
--

CREATE SEQUENCE public.users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_user_id_seq OWNER TO vouchmorphn_user;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vouchmorphn_user
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users.user_id;


--
-- Name: vouchmorph_notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vouchmorph_notifications (
    id integer NOT NULL,
    swap_number character varying(255) NOT NULL,
    swap_pin character varying(255) NOT NULL,
    amount numeric(20,4) NOT NULL,
    user_phone character varying(20),
    destination_bank_id integer NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    acknowledged_at timestamp without time zone
);


ALTER TABLE public.vouchmorph_notifications OWNER TO postgres;

--
-- Name: vouchmorph_notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.vouchmorph_notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.vouchmorph_notifications_id_seq OWNER TO postgres;

--
-- Name: vouchmorph_notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.vouchmorph_notifications_id_seq OWNED BY public.vouchmorph_notifications.id;


--
-- Name: admins admin_id; Type: DEFAULT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.admins ALTER COLUMN admin_id SET DEFAULT nextval('public.admins_admin_id_seq'::regclass);


--
-- Name: aml_checks check_id; Type: DEFAULT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.aml_checks ALTER COLUMN check_id SET DEFAULT nextval('public.aml_checks_check_id_seq'::regclass);


--
-- Name: api_message_logs log_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_message_logs ALTER COLUMN log_id SET DEFAULT nextval('public.api_message_logs_log_id_seq'::regclass);


--
-- Name: audit_logs audit_id; Type: DEFAULT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN audit_id SET DEFAULT nextval('public.audit_logs_audit_id_seq'::regclass);


--
-- Name: cashout_authorizations auth_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cashout_authorizations ALTER COLUMN auth_id SET DEFAULT nextval('public.cashout_authorizations_auth_id_seq'::regclass);


--
-- Name: deposit_transactions deposit_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deposit_transactions ALTER COLUMN deposit_id SET DEFAULT nextval('public.deposit_transactions_deposit_id_seq'::regclass);


--
-- Name: hold_transactions hold_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hold_transactions ALTER COLUMN hold_id SET DEFAULT nextval('public.hold_transactions_hold_id_seq'::regclass);


--
-- Name: kyc_documents kyc_id; Type: DEFAULT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.kyc_documents ALTER COLUMN kyc_id SET DEFAULT nextval('public.kyc_documents_kyc_id_seq'::regclass);


--
-- Name: ledger_accounts account_id; Type: DEFAULT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.ledger_accounts ALTER COLUMN account_id SET DEFAULT nextval('public.ledger_accounts_account_id_seq'::regclass);


--
-- Name: ledger_entries entry_id; Type: DEFAULT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.ledger_entries ALTER COLUMN entry_id SET DEFAULT nextval('public.ledger_entries_entry_id_seq'::regclass);


--
-- Name: net_positions id; Type: DEFAULT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.net_positions ALTER COLUMN id SET DEFAULT nextval('public.net_positions_id_seq'::regclass);


--
-- Name: otp_logs otp_id; Type: DEFAULT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.otp_logs ALTER COLUMN otp_id SET DEFAULT nextval('public.otp_logs_otp_id_seq'::regclass);


--
-- Name: participant_fee_overrides override_id; Type: DEFAULT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.participant_fee_overrides ALTER COLUMN override_id SET DEFAULT nextval('public.participant_fee_overrides_override_id_seq'::regclass);


--
-- Name: participants participant_id; Type: DEFAULT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.participants ALTER COLUMN participant_id SET DEFAULT nextval('public.participants_participant_id_seq'::regclass);


--
-- Name: regulator_outbox id; Type: DEFAULT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.regulator_outbox ALTER COLUMN id SET DEFAULT nextval('public.regulator_outbox_id_seq'::regclass);


--
-- Name: roles role_id; Type: DEFAULT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.roles ALTER COLUMN role_id SET DEFAULT nextval('public.roles_role_id_seq'::regclass);


--
-- Name: sandbox_disclosures id; Type: DEFAULT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.sandbox_disclosures ALTER COLUMN id SET DEFAULT nextval('public.sandbox_disclosures_id_seq'::regclass);


--
-- Name: send_to_other_transactions send_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.send_to_other_transactions ALTER COLUMN send_id SET DEFAULT nextval('public.send_to_other_transactions_send_id_seq'::regclass);


--
-- Name: settlement_messages message_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.settlement_messages ALTER COLUMN message_id SET DEFAULT nextval('public.settlement_messages_message_id_seq'::regclass);


--
-- Name: settlement_queue id; Type: DEFAULT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.settlement_queue ALTER COLUMN id SET DEFAULT nextval('public.settlement_queue_id_seq'::regclass);


--
-- Name: supervisory_heartbeat heartbeat_id; Type: DEFAULT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.supervisory_heartbeat ALTER COLUMN heartbeat_id SET DEFAULT nextval('public.supervisory_heartbeat_heartbeat_id_seq'::regclass);


--
-- Name: swap_fee_collections fee_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.swap_fee_collections ALTER COLUMN fee_id SET DEFAULT nextval('public.swap_fee_collections_fee_id_seq'::regclass);


--
-- Name: swap_ledgers ledger_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.swap_ledgers ALTER COLUMN ledger_id SET DEFAULT nextval('public.swap_ledgers_ledger_id_seq'::regclass);


--
-- Name: swap_requests swap_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.swap_requests ALTER COLUMN swap_id SET DEFAULT nextval('public.swap_requests_swap_id_seq'::regclass);


--
-- Name: swap_transactions swap_transaction_id; Type: DEFAULT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.swap_transactions ALTER COLUMN swap_transaction_id SET DEFAULT nextval('public.swap_transactions_swap_transaction_id_seq'::regclass);


--
-- Name: swap_vouchers voucher_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.swap_vouchers ALTER COLUMN voucher_id SET DEFAULT nextval('public.swap_vouchers_voucher_id_seq'::regclass);


--
-- Name: transaction_fees fee_id; Type: DEFAULT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.transaction_fees ALTER COLUMN fee_id SET DEFAULT nextval('public.transaction_fees_fee_id_seq'::regclass);


--
-- Name: transaction_splits split_id; Type: DEFAULT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.transaction_splits ALTER COLUMN split_id SET DEFAULT nextval('public.transaction_splits_split_id_seq'::regclass);


--
-- Name: transactions transaction_id; Type: DEFAULT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.transactions ALTER COLUMN transaction_id SET DEFAULT nextval('public.transactions_transaction_id_seq'::regclass);


--
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Name: vouchmorph_notifications id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vouchmorph_notifications ALTER COLUMN id SET DEFAULT nextval('public.vouchmorph_notifications_id_seq'::regclass);


--
-- Data for Name: admins; Type: TABLE DATA; Schema: public; Owner: vouchmorphn_user
--

COPY public.admins (admin_id, username, email, phone, password_hash, role_id, mfa_enabled, created_at, updated_at) FROM stdin;
\.
COPY public.admins (admin_id, username, email, phone, password_hash, role_id, mfa_enabled, created_at, updated_at) FROM '$$PATH$$/3950.dat';

--
-- Data for Name: aml_checks; Type: TABLE DATA; Schema: public; Owner: vouchmorphn_user
--

COPY public.aml_checks (check_id, user_id, check_type, check_reference, risk_score, status, findings, performed_by, performed_at, expiry_date, created_at) FROM stdin;
\.
COPY public.aml_checks (check_id, user_id, check_type, check_reference, risk_score, status, findings, performed_by, performed_at, expiry_date, created_at) FROM '$$PATH$$/3964.dat';

--
-- Data for Name: api_message_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_message_logs (log_id, message_id, message_type, direction, participant_id, participant_name, endpoint, request_payload, response_payload, http_status_code, curl_error, success, duration_ms, retry_count, created_at, processed_at) FROM stdin;
\.
COPY public.api_message_logs (log_id, message_id, message_type, direction, participant_id, participant_name, endpoint, request_payload, response_payload, http_status_code, curl_error, success, duration_ms, retry_count, created_at, processed_at) FROM '$$PATH$$/4003.dat';

--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: vouchmorphn_user
--

COPY public.audit_logs (audit_id, audit_uuid, entity_type, entity_id, action, category, severity, old_value, new_value, changes, performed_by_type, performed_by_id, ip_address, user_agent, geo_location, request_id, performed_at) FROM stdin;
\.
COPY public.audit_logs (audit_id, audit_uuid, entity_type, entity_id, action, category, severity, old_value, new_value, changes, performed_by_type, performed_by_id, ip_address, user_agent, geo_location, request_id, performed_at) FROM '$$PATH$$/3968.dat';

--
-- Data for Name: cashout_authorizations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cashout_authorizations (auth_id, swap_reference, client_phone, source_institution, source_wallet, amount, currency, fee_amount, swap_code, pin_code, code_expiry, cashout_point, cashout_provider, status, created_at, updated_at, completed_at, code_used_at, metadata) FROM stdin;
\.
COPY public.cashout_authorizations (auth_id, swap_reference, client_phone, source_institution, source_wallet, amount, currency, fee_amount, swap_code, pin_code, code_expiry, cashout_point, cashout_provider, status, created_at, updated_at, completed_at, code_used_at, metadata) FROM '$$PATH$$/3988.dat';

--
-- Data for Name: deposit_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.deposit_transactions (deposit_id, transaction_reference, client_phone, source_type, source_institution, source_account, destination_type, destination_institution, destination_account, amount, currency, fee_amount, status, created_at, updated_at, completed_at, metadata) FROM stdin;
\.
COPY public.deposit_transactions (deposit_id, transaction_reference, client_phone, source_type, source_institution, source_account, destination_type, destination_institution, destination_account, amount, currency, fee_amount, status, created_at, updated_at, completed_at, metadata) FROM '$$PATH$$/3986.dat';

--
-- Data for Name: hold_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.hold_transactions (hold_id, hold_reference, swap_reference, participant_id, participant_name, asset_type, amount, currency, status, hold_expiry, source_details, destination_institution, destination_participant_id, metadata, placed_at, released_at, debited_at, created_at, updated_at) FROM stdin;
\.
COPY public.hold_transactions (hold_id, hold_reference, swap_reference, participant_id, participant_name, asset_type, amount, currency, status, hold_expiry, source_details, destination_institution, destination_participant_id, metadata, placed_at, released_at, debited_at, created_at, updated_at) FROM '$$PATH$$/4005.dat';

--
-- Data for Name: kyc_documents; Type: TABLE DATA; Schema: public; Owner: vouchmorphn_user
--

COPY public.kyc_documents (kyc_id, user_id, document_type, document_number, status, document_path, document_hash, expiry_date, admin_reviewer_id, review_date, review_notes, metadata, created_at, updated_at) FROM stdin;
\.
COPY public.kyc_documents (kyc_id, user_id, document_type, document_number, status, document_path, document_hash, expiry_date, admin_reviewer_id, review_date, review_notes, metadata, created_at, updated_at) FROM '$$PATH$$/3962.dat';

--
-- Data for Name: ledger_accounts; Type: TABLE DATA; Schema: public; Owner: vouchmorphn_user
--

COPY public.ledger_accounts (account_id, account_code, account_name, account_type, balance, participant_id, currency_code, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.ledger_accounts (account_id, account_code, account_name, account_type, balance, participant_id, currency_code, is_active, created_at, updated_at) FROM '$$PATH$$/3952.dat';

--
-- Data for Name: ledger_entries; Type: TABLE DATA; Schema: public; Owner: vouchmorphn_user
--

COPY public.ledger_entries (entry_id, transaction_id, debit_account_id, credit_account_id, amount, currency_code, reference, split_type, created_at, updated_at) FROM stdin;
\.
COPY public.ledger_entries (entry_id, transaction_id, debit_account_id, credit_account_id, amount, currency_code, reference, split_type, created_at, updated_at) FROM '$$PATH$$/3956.dat';

--
-- Data for Name: message_outbox; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.message_outbox (message_id, channel, destination, payload, status, created_at, sent_at) FROM stdin;
\.
COPY public.message_outbox (message_id, channel, destination, payload, status, created_at, sent_at) FROM '$$PATH$$/3999.dat';

--
-- Data for Name: net_positions; Type: TABLE DATA; Schema: public; Owner: vouchmorphn_user
--

COPY public.net_positions (id, debtor, creditor, amount, currency_code, created_at, updated_at) FROM stdin;
\.
COPY public.net_positions (id, debtor, creditor, amount, currency_code, created_at, updated_at) FROM '$$PATH$$/3984.dat';

--
-- Data for Name: otp_logs; Type: TABLE DATA; Schema: public; Owner: vouchmorphn_user
--

COPY public.otp_logs (otp_id, identifier, identifier_type, code_hash, purpose, expires_at, used_at, attempts, ip_address, user_agent, created_at) FROM stdin;
\.
COPY public.otp_logs (otp_id, identifier, identifier_type, code_hash, purpose, expires_at, used_at, attempts, ip_address, user_agent, created_at) FROM '$$PATH$$/3966.dat';

--
-- Data for Name: participant_fee_overrides; Type: TABLE DATA; Schema: public; Owner: vouchmorphn_user
--

COPY public.participant_fee_overrides (override_id, participant_id, transaction_type, fee_amount, split, active, created_at) FROM stdin;
\.
COPY public.participant_fee_overrides (override_id, participant_id, transaction_type, fee_amount, split, active, created_at) FROM '$$PATH$$/3982.dat';

--
-- Data for Name: participants; Type: TABLE DATA; Schema: public; Owner: vouchmorphn_user
--

COPY public.participants (participant_id, name, type, category, provider_code, auth_type, base_url, system_user_id, legal_entity_identifier, license_number, settlement_account, settlement_type, status, capabilities, resource_endpoints, phone_format, security_config, message_profile, routing_info, metadata) FROM stdin;
\.
COPY public.participants (participant_id, name, type, category, provider_code, auth_type, base_url, system_user_id, legal_entity_identifier, license_number, settlement_account, settlement_type, status, capabilities, resource_endpoints, phone_format, security_config, message_profile, routing_info, metadata) FROM '$$PATH$$/3980.dat';

--
-- Data for Name: regulator_outbox; Type: TABLE DATA; Schema: public; Owner: vouchmorphn_user
--

COPY public.regulator_outbox (id, report_id, payload, integrity_hash, status, attempts, last_attempt, created_at) FROM stdin;
\.
COPY public.regulator_outbox (id, report_id, payload, integrity_hash, status, attempts, last_attempt, created_at) FROM '$$PATH$$/3970.dat';

--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: vouchmorphn_user
--

COPY public.roles (role_id, role_name, description, permissions, created_at, updated_at) FROM stdin;
\.
COPY public.roles (role_id, role_name, description, permissions, created_at, updated_at) FROM '$$PATH$$/3946.dat';

--
-- Data for Name: sandbox_disclosures; Type: TABLE DATA; Schema: public; Owner: vouchmorphn_user
--

COPY public.sandbox_disclosures (id, user_id, consent_version, has_accepted, disclosure_text, experimental_risk_acknowledged_at) FROM stdin;
\.
COPY public.sandbox_disclosures (id, user_id, consent_version, has_accepted, disclosure_text, experimental_risk_acknowledged_at) FROM '$$PATH$$/3974.dat';

--
-- Data for Name: send_to_other_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.send_to_other_transactions (send_id, transaction_reference, sender_phone, sender_institution, sender_account, receiver_phone, receiver_institution, receiver_account, amount, currency, fee_amount, status, created_at, updated_at, completed_at, notification_sent, metadata) FROM stdin;
\.
COPY public.send_to_other_transactions (send_id, transaction_reference, sender_phone, sender_institution, sender_account, receiver_phone, receiver_institution, receiver_account, amount, currency, fee_amount, status, created_at, updated_at, completed_at, notification_sent, metadata) FROM '$$PATH$$/3990.dat';

--
-- Data for Name: settlement_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.settlement_messages (message_id, transaction_id, from_participant, to_participant, amount, type, status, metadata, created_at, processed_at) FROM stdin;
\.
COPY public.settlement_messages (message_id, transaction_id, from_participant, to_participant, amount, type, status, metadata, created_at, processed_at) FROM '$$PATH$$/4001.dat';

--
-- Data for Name: settlement_queue; Type: TABLE DATA; Schema: public; Owner: vouchmorphn_user
--

COPY public.settlement_queue (id, debtor, creditor, amount, created_at, updated_at) FROM stdin;
\.
COPY public.settlement_queue (id, debtor, creditor, amount, created_at, updated_at) FROM '$$PATH$$/3978.dat';

--
-- Data for Name: supervisory_heartbeat; Type: TABLE DATA; Schema: public; Owner: vouchmorphn_user
--

COPY public.supervisory_heartbeat (heartbeat_id, status, created_at, latency_ms, system_load) FROM stdin;
\.
COPY public.supervisory_heartbeat (heartbeat_id, status, created_at, latency_ms, system_load) FROM '$$PATH$$/3972.dat';

--
-- Data for Name: swap_fee_collections; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.swap_fee_collections (fee_id, swap_reference, fee_type, total_amount, currency, source_institution, destination_institution, split_config, vat_amount, status, collected_at, settled_at, created_at, updated_at) FROM stdin;
\.
COPY public.swap_fee_collections (fee_id, swap_reference, fee_type, total_amount, currency, source_institution, destination_institution, split_config, vat_amount, status, collected_at, settled_at, created_at, updated_at) FROM '$$PATH$$/4007.dat';

--
-- Data for Name: swap_ledgers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.swap_ledgers (ledger_id, swap_reference, from_institution, to_institution, amount, currency_code, swap_fee, status, created_at) FROM stdin;
\.
COPY public.swap_ledgers (ledger_id, swap_reference, from_institution, to_institution, amount, currency_code, swap_fee, status, created_at) FROM '$$PATH$$/3998.dat';

--
-- Data for Name: swap_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.swap_requests (swap_id, swap_uuid, from_currency, to_currency, amount, source_details, destination_details, status, created_at) FROM stdin;
\.
COPY public.swap_requests (swap_id, swap_uuid, from_currency, to_currency, amount, source_details, destination_details, status, created_at) FROM '$$PATH$$/3994.dat';

--
-- Data for Name: swap_transactions; Type: TABLE DATA; Schema: public; Owner: vouchmorphn_user
--

COPY public.swap_transactions (swap_transaction_id, swap_id, transaction_id, from_account_details, to_account_details, amount, ledger_entry_id, settlement_batch_id, status, error_message, retry_count, metadata, created_at, updated_at) FROM stdin;
\.
COPY public.swap_transactions (swap_transaction_id, swap_id, transaction_id, from_account_details, to_account_details, amount, ledger_entry_id, settlement_batch_id, status, error_message, retry_count, metadata, created_at, updated_at) FROM '$$PATH$$/3960.dat';

--
-- Data for Name: swap_vouchers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.swap_vouchers (voucher_id, swap_id, code_hash, code_suffix, amount, expiry_at, status, claimant_phone, is_cardless_redemption, created_at) FROM stdin;
\.
COPY public.swap_vouchers (voucher_id, swap_id, code_hash, code_suffix, amount, expiry_at, status, claimant_phone, is_cardless_redemption, created_at) FROM '$$PATH$$/3996.dat';

--
-- Data for Name: transaction_fees; Type: TABLE DATA; Schema: public; Owner: vouchmorphn_user
--

COPY public.transaction_fees (fee_id, transaction_type, amount, currency, split_config, taxable, created_at) FROM stdin;
\.
COPY public.transaction_fees (fee_id, transaction_type, amount, currency, split_config, taxable, created_at) FROM '$$PATH$$/3976.dat';

--
-- Data for Name: transaction_splits; Type: TABLE DATA; Schema: public; Owner: vouchmorphn_user
--

COPY public.transaction_splits (split_id, transaction_id, split_type, amount, currency_code, credited_account, created_at) FROM stdin;
\.
COPY public.transaction_splits (split_id, transaction_id, split_type, amount, currency_code, credited_account, created_at) FROM '$$PATH$$/3958.dat';

--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: vouchmorphn_user
--

COPY public.transactions (transaction_id, transaction_type, amount, fee, sat_purchased, currency_code, status, sca_required, sca_verified_at, reference_uuid, created_at, updated_at, origin_participant_id, destination_participant_id, origin_name, destination_name) FROM stdin;
\.
COPY public.transactions (transaction_id, transaction_type, amount, fee, sat_purchased, currency_code, status, sca_required, sca_verified_at, reference_uuid, created_at, updated_at, origin_participant_id, destination_participant_id, origin_name, destination_name) FROM '$$PATH$$/3954.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: vouchmorphn_user
--

COPY public.users (user_id, username, email, phone, password_hash, role_id, verified, kyc_verified, aml_score, mfa_enabled, created_at, updated_at) FROM stdin;
\.
COPY public.users (user_id, username, email, phone, password_hash, role_id, verified, kyc_verified, aml_score, mfa_enabled, created_at, updated_at) FROM '$$PATH$$/3948.dat';

--
-- Data for Name: vouchmorph_notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vouchmorph_notifications (id, swap_number, swap_pin, amount, user_phone, destination_bank_id, status, created_at, acknowledged_at) FROM stdin;
\.
COPY public.vouchmorph_notifications (id, swap_number, swap_pin, amount, user_phone, destination_bank_id, status, created_at, acknowledged_at) FROM '$$PATH$$/3992.dat';

--
-- Name: admins_admin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vouchmorphn_user
--

SELECT pg_catalog.setval('public.admins_admin_id_seq', 1, false);


--
-- Name: aml_checks_check_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vouchmorphn_user
--

SELECT pg_catalog.setval('public.aml_checks_check_id_seq', 1, false);


--
-- Name: api_message_logs_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.api_message_logs_log_id_seq', 88, true);


--
-- Name: audit_logs_audit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vouchmorphn_user
--

SELECT pg_catalog.setval('public.audit_logs_audit_id_seq', 74, true);


--
-- Name: cashout_authorizations_auth_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cashout_authorizations_auth_id_seq', 1, false);


--
-- Name: deposit_transactions_deposit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.deposit_transactions_deposit_id_seq', 1, false);


--
-- Name: hold_transactions_hold_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.hold_transactions_hold_id_seq', 20, true);


--
-- Name: kyc_documents_kyc_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vouchmorphn_user
--

SELECT pg_catalog.setval('public.kyc_documents_kyc_id_seq', 1, false);


--
-- Name: ledger_accounts_account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vouchmorphn_user
--

SELECT pg_catalog.setval('public.ledger_accounts_account_id_seq', 13, true);


--
-- Name: ledger_entries_entry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vouchmorphn_user
--

SELECT pg_catalog.setval('public.ledger_entries_entry_id_seq', 43, true);


--
-- Name: net_positions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vouchmorphn_user
--

SELECT pg_catalog.setval('public.net_positions_id_seq', 11, true);


--
-- Name: otp_logs_otp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vouchmorphn_user
--

SELECT pg_catalog.setval('public.otp_logs_otp_id_seq', 1, false);


--
-- Name: participant_fee_overrides_override_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vouchmorphn_user
--

SELECT pg_catalog.setval('public.participant_fee_overrides_override_id_seq', 2, true);


--
-- Name: participants_participant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vouchmorphn_user
--

SELECT pg_catalog.setval('public.participants_participant_id_seq', 6, true);


--
-- Name: regulator_outbox_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vouchmorphn_user
--

SELECT pg_catalog.setval('public.regulator_outbox_id_seq', 41, true);


--
-- Name: roles_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vouchmorphn_user
--

SELECT pg_catalog.setval('public.roles_role_id_seq', 10, true);


--
-- Name: sandbox_disclosures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vouchmorphn_user
--

SELECT pg_catalog.setval('public.sandbox_disclosures_id_seq', 1, false);


--
-- Name: send_to_other_transactions_send_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.send_to_other_transactions_send_id_seq', 1, false);


--
-- Name: settlement_messages_message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.settlement_messages_message_id_seq', 21, true);


--
-- Name: settlement_queue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vouchmorphn_user
--

SELECT pg_catalog.setval('public.settlement_queue_id_seq', 10, true);


--
-- Name: supervisory_heartbeat_heartbeat_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vouchmorphn_user
--

SELECT pg_catalog.setval('public.supervisory_heartbeat_heartbeat_id_seq', 2, true);


--
-- Name: swap_fee_collections_fee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.swap_fee_collections_fee_id_seq', 14, true);


--
-- Name: swap_ledgers_ledger_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.swap_ledgers_ledger_id_seq', 12, true);


--
-- Name: swap_requests_swap_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.swap_requests_swap_id_seq', 65, true);


--
-- Name: swap_transactions_swap_transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vouchmorphn_user
--

SELECT pg_catalog.setval('public.swap_transactions_swap_transaction_id_seq', 1, false);


--
-- Name: swap_vouchers_voucher_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.swap_vouchers_voucher_id_seq', 34, true);


--
-- Name: transaction_fees_fee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vouchmorphn_user
--

SELECT pg_catalog.setval('public.transaction_fees_fee_id_seq', 4, true);


--
-- Name: transaction_splits_split_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vouchmorphn_user
--

SELECT pg_catalog.setval('public.transaction_splits_split_id_seq', 1, false);


--
-- Name: transactions_transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vouchmorphn_user
--

SELECT pg_catalog.setval('public.transactions_transaction_id_seq', 43, true);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vouchmorphn_user
--

SELECT pg_catalog.setval('public.users_user_id_seq', 1, true);


--
-- Name: vouchmorph_notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.vouchmorph_notifications_id_seq', 1, false);


--
-- Name: admins admins_email_key; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_email_key UNIQUE (email);


--
-- Name: admins admins_pkey; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_pkey PRIMARY KEY (admin_id);


--
-- Name: admins admins_username_key; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_username_key UNIQUE (username);


--
-- Name: aml_checks aml_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.aml_checks
    ADD CONSTRAINT aml_checks_pkey PRIMARY KEY (check_id);


--
-- Name: api_message_logs api_message_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_message_logs
    ADD CONSTRAINT api_message_logs_pkey PRIMARY KEY (log_id);


--
-- Name: audit_logs audit_logs_audit_uuid_key; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_audit_uuid_key UNIQUE (audit_uuid);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (audit_id);


--
-- Name: cashout_authorizations cashout_authorizations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cashout_authorizations
    ADD CONSTRAINT cashout_authorizations_pkey PRIMARY KEY (auth_id);


--
-- Name: cashout_authorizations cashout_authorizations_swap_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cashout_authorizations
    ADD CONSTRAINT cashout_authorizations_swap_code_key UNIQUE (swap_code);


--
-- Name: cashout_authorizations cashout_authorizations_swap_reference_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cashout_authorizations
    ADD CONSTRAINT cashout_authorizations_swap_reference_key UNIQUE (swap_reference);


--
-- Name: deposit_transactions deposit_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deposit_transactions
    ADD CONSTRAINT deposit_transactions_pkey PRIMARY KEY (deposit_id);


--
-- Name: deposit_transactions deposit_transactions_transaction_reference_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deposit_transactions
    ADD CONSTRAINT deposit_transactions_transaction_reference_key UNIQUE (transaction_reference);


--
-- Name: hold_transactions hold_transactions_hold_reference_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hold_transactions
    ADD CONSTRAINT hold_transactions_hold_reference_key UNIQUE (hold_reference);


--
-- Name: hold_transactions hold_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hold_transactions
    ADD CONSTRAINT hold_transactions_pkey PRIMARY KEY (hold_id);


--
-- Name: kyc_documents kyc_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.kyc_documents
    ADD CONSTRAINT kyc_documents_pkey PRIMARY KEY (kyc_id);


--
-- Name: ledger_accounts ledger_accounts_account_code_key; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.ledger_accounts
    ADD CONSTRAINT ledger_accounts_account_code_key UNIQUE (account_code);


--
-- Name: ledger_accounts ledger_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.ledger_accounts
    ADD CONSTRAINT ledger_accounts_pkey PRIMARY KEY (account_id);


--
-- Name: ledger_entries ledger_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.ledger_entries
    ADD CONSTRAINT ledger_entries_pkey PRIMARY KEY (entry_id);


--
-- Name: message_outbox message_outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.message_outbox
    ADD CONSTRAINT message_outbox_pkey PRIMARY KEY (message_id);


--
-- Name: net_positions net_positions_debtor_creditor_key; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.net_positions
    ADD CONSTRAINT net_positions_debtor_creditor_key UNIQUE (debtor, creditor);


--
-- Name: net_positions net_positions_pkey; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.net_positions
    ADD CONSTRAINT net_positions_pkey PRIMARY KEY (id);


--
-- Name: otp_logs otp_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.otp_logs
    ADD CONSTRAINT otp_logs_pkey PRIMARY KEY (otp_id);


--
-- Name: participant_fee_overrides participant_fee_overrides_participant_id_transaction_type_key; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.participant_fee_overrides
    ADD CONSTRAINT participant_fee_overrides_participant_id_transaction_type_key UNIQUE (participant_id, transaction_type);


--
-- Name: participant_fee_overrides participant_fee_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.participant_fee_overrides
    ADD CONSTRAINT participant_fee_overrides_pkey PRIMARY KEY (override_id);


--
-- Name: participants participants_name_key; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.participants
    ADD CONSTRAINT participants_name_key UNIQUE (name);


--
-- Name: participants participants_pkey; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.participants
    ADD CONSTRAINT participants_pkey PRIMARY KEY (participant_id);


--
-- Name: regulator_outbox regulator_outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.regulator_outbox
    ADD CONSTRAINT regulator_outbox_pkey PRIMARY KEY (id);


--
-- Name: regulator_outbox regulator_outbox_report_id_key; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.regulator_outbox
    ADD CONSTRAINT regulator_outbox_report_id_key UNIQUE (report_id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (role_id);


--
-- Name: roles roles_role_name_key; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_role_name_key UNIQUE (role_name);


--
-- Name: sandbox_disclosures sandbox_disclosures_pkey; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.sandbox_disclosures
    ADD CONSTRAINT sandbox_disclosures_pkey PRIMARY KEY (id);


--
-- Name: send_to_other_transactions send_to_other_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.send_to_other_transactions
    ADD CONSTRAINT send_to_other_transactions_pkey PRIMARY KEY (send_id);


--
-- Name: send_to_other_transactions send_to_other_transactions_transaction_reference_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.send_to_other_transactions
    ADD CONSTRAINT send_to_other_transactions_transaction_reference_key UNIQUE (transaction_reference);


--
-- Name: settlement_messages settlement_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.settlement_messages
    ADD CONSTRAINT settlement_messages_pkey PRIMARY KEY (message_id);


--
-- Name: settlement_queue settlement_queue_debtor_creditor_key; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.settlement_queue
    ADD CONSTRAINT settlement_queue_debtor_creditor_key UNIQUE (debtor, creditor);


--
-- Name: settlement_queue settlement_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.settlement_queue
    ADD CONSTRAINT settlement_queue_pkey PRIMARY KEY (id);


--
-- Name: supervisory_heartbeat supervisory_heartbeat_pkey; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.supervisory_heartbeat
    ADD CONSTRAINT supervisory_heartbeat_pkey PRIMARY KEY (heartbeat_id);


--
-- Name: swap_fee_collections swap_fee_collections_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.swap_fee_collections
    ADD CONSTRAINT swap_fee_collections_pkey PRIMARY KEY (fee_id);


--
-- Name: swap_ledgers swap_ledgers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.swap_ledgers
    ADD CONSTRAINT swap_ledgers_pkey PRIMARY KEY (ledger_id);


--
-- Name: swap_requests swap_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.swap_requests
    ADD CONSTRAINT swap_requests_pkey PRIMARY KEY (swap_id);


--
-- Name: swap_requests swap_requests_swap_uuid_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.swap_requests
    ADD CONSTRAINT swap_requests_swap_uuid_key UNIQUE (swap_uuid);


--
-- Name: swap_transactions swap_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.swap_transactions
    ADD CONSTRAINT swap_transactions_pkey PRIMARY KEY (swap_transaction_id);


--
-- Name: swap_vouchers swap_vouchers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.swap_vouchers
    ADD CONSTRAINT swap_vouchers_pkey PRIMARY KEY (voucher_id);


--
-- Name: transaction_fees transaction_fees_pkey; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.transaction_fees
    ADD CONSTRAINT transaction_fees_pkey PRIMARY KEY (fee_id);


--
-- Name: transaction_fees transaction_fees_transaction_type_key; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.transaction_fees
    ADD CONSTRAINT transaction_fees_transaction_type_key UNIQUE (transaction_type);


--
-- Name: transaction_splits transaction_splits_pkey; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.transaction_splits
    ADD CONSTRAINT transaction_splits_pkey PRIMARY KEY (split_id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (transaction_id);


--
-- Name: transactions transactions_reference_uuid_key; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_reference_uuid_key UNIQUE (reference_uuid);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: vouchmorph_notifications vouchmorph_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vouchmorph_notifications
    ADD CONSTRAINT vouchmorph_notifications_pkey PRIMARY KEY (id);


--
-- Name: idx_api_logs_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_api_logs_created ON public.api_message_logs USING btree (created_at);


--
-- Name: idx_api_logs_message_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_api_logs_message_id ON public.api_message_logs USING btree (message_id);


--
-- Name: idx_api_logs_participant; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_api_logs_participant ON public.api_message_logs USING btree (participant_id);


--
-- Name: idx_api_logs_success; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_api_logs_success ON public.api_message_logs USING btree (success) WHERE (success = false);


--
-- Name: idx_api_logs_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_api_logs_type ON public.api_message_logs USING btree (message_type);


--
-- Name: idx_cashout_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cashout_code ON public.cashout_authorizations USING btree (swap_code) WHERE ((status)::text = 'ACTIVE'::text);


--
-- Name: idx_cashout_expiry; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cashout_expiry ON public.cashout_authorizations USING btree (code_expiry) WHERE ((status)::text = 'ACTIVE'::text);


--
-- Name: idx_cashout_phone; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cashout_phone ON public.cashout_authorizations USING btree (client_phone, created_at);


--
-- Name: idx_cashout_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cashout_status ON public.cashout_authorizations USING btree (status);


--
-- Name: idx_deposit_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_deposit_created ON public.deposit_transactions USING btree (created_at);


--
-- Name: idx_deposit_phone; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_deposit_phone ON public.deposit_transactions USING btree (client_phone, created_at);


--
-- Name: idx_deposit_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_deposit_status ON public.deposit_transactions USING btree (status);


--
-- Name: idx_fee_collections_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fee_collections_date ON public.swap_fee_collections USING btree (collected_at);


--
-- Name: idx_fee_collections_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fee_collections_status ON public.swap_fee_collections USING btree (status);


--
-- Name: idx_fee_collections_swap_ref; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fee_collections_swap_ref ON public.swap_fee_collections USING btree (swap_reference);


--
-- Name: idx_holds_reference; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_holds_reference ON public.hold_transactions USING btree (hold_reference);


--
-- Name: idx_holds_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_holds_status ON public.hold_transactions USING btree (status);


--
-- Name: idx_holds_swap; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_holds_swap ON public.hold_transactions USING btree (swap_reference);


--
-- Name: idx_message_outbox_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_message_outbox_status ON public.message_outbox USING btree (status);


--
-- Name: idx_net_positions_creditor; Type: INDEX; Schema: public; Owner: vouchmorphn_user
--

CREATE INDEX idx_net_positions_creditor ON public.net_positions USING btree (creditor);


--
-- Name: idx_net_positions_debtor; Type: INDEX; Schema: public; Owner: vouchmorphn_user
--

CREATE INDEX idx_net_positions_debtor ON public.net_positions USING btree (debtor);


--
-- Name: idx_send_receiver; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_send_receiver ON public.send_to_other_transactions USING btree (receiver_phone, created_at);


--
-- Name: idx_send_sender; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_send_sender ON public.send_to_other_transactions USING btree (sender_phone, created_at);


--
-- Name: idx_send_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_send_status ON public.send_to_other_transactions USING btree (status);


--
-- Name: idx_settlement_messages_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_settlement_messages_status ON public.settlement_messages USING btree (status);


--
-- Name: idx_settlement_queue_created; Type: INDEX; Schema: public; Owner: vouchmorphn_user
--

CREATE INDEX idx_settlement_queue_created ON public.settlement_queue USING btree (created_at);


--
-- Name: idx_swap_requests_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_swap_requests_status ON public.swap_requests USING btree (status);


--
-- Name: idx_swap_requests_uuid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_swap_requests_uuid ON public.swap_requests USING btree (swap_uuid);


--
-- Name: idx_swap_vouchers_phone; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_swap_vouchers_phone ON public.swap_vouchers USING btree (claimant_phone);


--
-- Name: idx_swap_vouchers_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_swap_vouchers_status ON public.swap_vouchers USING btree (status);


--
-- Name: admins trg_admins_updated; Type: TRIGGER; Schema: public; Owner: vouchmorphn_user
--

CREATE TRIGGER trg_admins_updated BEFORE UPDATE ON public.admins FOR EACH ROW EXECUTE FUNCTION public.fn_update_timestamp();


--
-- Name: aml_checks trg_aml_checks_updated; Type: TRIGGER; Schema: public; Owner: vouchmorphn_user
--

CREATE TRIGGER trg_aml_checks_updated BEFORE UPDATE ON public.aml_checks FOR EACH ROW EXECUTE FUNCTION public.fn_update_timestamp();


--
-- Name: audit_logs trg_audit_logs_updated; Type: TRIGGER; Schema: public; Owner: vouchmorphn_user
--

CREATE TRIGGER trg_audit_logs_updated BEFORE UPDATE ON public.audit_logs FOR EACH ROW EXECUTE FUNCTION public.fn_update_timestamp();


--
-- Name: kyc_documents trg_kyc_documents_updated; Type: TRIGGER; Schema: public; Owner: vouchmorphn_user
--

CREATE TRIGGER trg_kyc_documents_updated BEFORE UPDATE ON public.kyc_documents FOR EACH ROW EXECUTE FUNCTION public.fn_update_timestamp();


--
-- Name: ledger_accounts trg_ledger_accounts_updated; Type: TRIGGER; Schema: public; Owner: vouchmorphn_user
--

CREATE TRIGGER trg_ledger_accounts_updated BEFORE UPDATE ON public.ledger_accounts FOR EACH ROW EXECUTE FUNCTION public.fn_update_timestamp();


--
-- Name: ledger_entries trg_ledger_entries_updated; Type: TRIGGER; Schema: public; Owner: vouchmorphn_user
--

CREATE TRIGGER trg_ledger_entries_updated BEFORE UPDATE ON public.ledger_entries FOR EACH ROW EXECUTE FUNCTION public.fn_update_timestamp();


--
-- Name: otp_logs trg_otp_logs_updated; Type: TRIGGER; Schema: public; Owner: vouchmorphn_user
--

CREATE TRIGGER trg_otp_logs_updated BEFORE UPDATE ON public.otp_logs FOR EACH ROW EXECUTE FUNCTION public.fn_update_timestamp();


--
-- Name: regulator_outbox trg_regulator_outbox_updated; Type: TRIGGER; Schema: public; Owner: vouchmorphn_user
--

CREATE TRIGGER trg_regulator_outbox_updated BEFORE UPDATE ON public.regulator_outbox FOR EACH ROW EXECUTE FUNCTION public.fn_update_timestamp();


--
-- Name: roles trg_roles_updated; Type: TRIGGER; Schema: public; Owner: vouchmorphn_user
--

CREATE TRIGGER trg_roles_updated BEFORE UPDATE ON public.roles FOR EACH ROW EXECUTE FUNCTION public.fn_update_timestamp();


--
-- Name: sandbox_disclosures trg_sandbox_disclosures_updated; Type: TRIGGER; Schema: public; Owner: vouchmorphn_user
--

CREATE TRIGGER trg_sandbox_disclosures_updated BEFORE UPDATE ON public.sandbox_disclosures FOR EACH ROW EXECUTE FUNCTION public.fn_update_timestamp();


--
-- Name: supervisory_heartbeat trg_supervisory_heartbeat_updated; Type: TRIGGER; Schema: public; Owner: vouchmorphn_user
--

CREATE TRIGGER trg_supervisory_heartbeat_updated BEFORE UPDATE ON public.supervisory_heartbeat FOR EACH ROW EXECUTE FUNCTION public.fn_update_timestamp();


--
-- Name: swap_transactions trg_swap_transactions_updated; Type: TRIGGER; Schema: public; Owner: vouchmorphn_user
--

CREATE TRIGGER trg_swap_transactions_updated BEFORE UPDATE ON public.swap_transactions FOR EACH ROW EXECUTE FUNCTION public.fn_update_timestamp();


--
-- Name: transaction_splits trg_transaction_splits_updated; Type: TRIGGER; Schema: public; Owner: vouchmorphn_user
--

CREATE TRIGGER trg_transaction_splits_updated BEFORE UPDATE ON public.transaction_splits FOR EACH ROW EXECUTE FUNCTION public.fn_update_timestamp();


--
-- Name: transactions trg_transactions_updated; Type: TRIGGER; Schema: public; Owner: vouchmorphn_user
--

CREATE TRIGGER trg_transactions_updated BEFORE UPDATE ON public.transactions FOR EACH ROW EXECUTE FUNCTION public.fn_update_timestamp();


--
-- Name: users trg_users_updated; Type: TRIGGER; Schema: public; Owner: vouchmorphn_user
--

CREATE TRIGGER trg_users_updated BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.fn_update_timestamp();


--
-- Name: admins update_admins_updated_at; Type: TRIGGER; Schema: public; Owner: vouchmorphn_user
--

CREATE TRIGGER update_admins_updated_at BEFORE UPDATE ON public.admins FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: hold_transactions update_hold_transactions_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_hold_transactions_updated_at BEFORE UPDATE ON public.hold_transactions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: kyc_documents update_kyc_documents_updated_at; Type: TRIGGER; Schema: public; Owner: vouchmorphn_user
--

CREATE TRIGGER update_kyc_documents_updated_at BEFORE UPDATE ON public.kyc_documents FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: ledger_accounts update_ledger_accounts_updated_at; Type: TRIGGER; Schema: public; Owner: vouchmorphn_user
--

CREATE TRIGGER update_ledger_accounts_updated_at BEFORE UPDATE ON public.ledger_accounts FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: ledger_entries update_ledger_entries_updated_at; Type: TRIGGER; Schema: public; Owner: vouchmorphn_user
--

CREATE TRIGGER update_ledger_entries_updated_at BEFORE UPDATE ON public.ledger_entries FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: net_positions update_net_positions_updated_at; Type: TRIGGER; Schema: public; Owner: vouchmorphn_user
--

CREATE TRIGGER update_net_positions_updated_at BEFORE UPDATE ON public.net_positions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: participants update_participants_updated_at; Type: TRIGGER; Schema: public; Owner: vouchmorphn_user
--

CREATE TRIGGER update_participants_updated_at BEFORE UPDATE ON public.participants FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: roles update_roles_updated_at; Type: TRIGGER; Schema: public; Owner: vouchmorphn_user
--

CREATE TRIGGER update_roles_updated_at BEFORE UPDATE ON public.roles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: settlement_queue update_settlement_queue_updated_at; Type: TRIGGER; Schema: public; Owner: vouchmorphn_user
--

CREATE TRIGGER update_settlement_queue_updated_at BEFORE UPDATE ON public.settlement_queue FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: swap_fee_collections update_swap_fee_collections_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_swap_fee_collections_updated_at BEFORE UPDATE ON public.swap_fee_collections FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: swap_transactions update_swap_transactions_updated_at; Type: TRIGGER; Schema: public; Owner: vouchmorphn_user
--

CREATE TRIGGER update_swap_transactions_updated_at BEFORE UPDATE ON public.swap_transactions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: transactions update_transactions_updated_at; Type: TRIGGER; Schema: public; Owner: vouchmorphn_user
--

CREATE TRIGGER update_transactions_updated_at BEFORE UPDATE ON public.transactions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: vouchmorphn_user
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: admins admins_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(role_id);


--
-- Name: aml_checks aml_checks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.aml_checks
    ADD CONSTRAINT aml_checks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: api_message_logs api_message_logs_participant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_message_logs
    ADD CONSTRAINT api_message_logs_participant_id_fkey FOREIGN KEY (participant_id) REFERENCES public.participants(participant_id);


--
-- Name: hold_transactions hold_transactions_destination_participant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hold_transactions
    ADD CONSTRAINT hold_transactions_destination_participant_id_fkey FOREIGN KEY (destination_participant_id) REFERENCES public.participants(participant_id);


--
-- Name: hold_transactions hold_transactions_participant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hold_transactions
    ADD CONSTRAINT hold_transactions_participant_id_fkey FOREIGN KEY (participant_id) REFERENCES public.participants(participant_id);


--
-- Name: kyc_documents kyc_documents_admin_reviewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.kyc_documents
    ADD CONSTRAINT kyc_documents_admin_reviewer_id_fkey FOREIGN KEY (admin_reviewer_id) REFERENCES public.admins(admin_id);


--
-- Name: kyc_documents kyc_documents_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.kyc_documents
    ADD CONSTRAINT kyc_documents_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: ledger_entries ledger_entries_credit_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.ledger_entries
    ADD CONSTRAINT ledger_entries_credit_account_id_fkey FOREIGN KEY (credit_account_id) REFERENCES public.ledger_accounts(account_id);


--
-- Name: ledger_entries ledger_entries_debit_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.ledger_entries
    ADD CONSTRAINT ledger_entries_debit_account_id_fkey FOREIGN KEY (debit_account_id) REFERENCES public.ledger_accounts(account_id);


--
-- Name: ledger_entries ledger_entries_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.ledger_entries
    ADD CONSTRAINT ledger_entries_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.transactions(transaction_id);


--
-- Name: participant_fee_overrides participant_fee_overrides_participant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.participant_fee_overrides
    ADD CONSTRAINT participant_fee_overrides_participant_id_fkey FOREIGN KEY (participant_id) REFERENCES public.participants(participant_id) ON DELETE CASCADE;


--
-- Name: sandbox_disclosures sandbox_disclosures_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.sandbox_disclosures
    ADD CONSTRAINT sandbox_disclosures_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: swap_transactions swap_transactions_ledger_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.swap_transactions
    ADD CONSTRAINT swap_transactions_ledger_entry_id_fkey FOREIGN KEY (ledger_entry_id) REFERENCES public.ledger_entries(entry_id);


--
-- Name: swap_transactions swap_transactions_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.swap_transactions
    ADD CONSTRAINT swap_transactions_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.transactions(transaction_id);


--
-- Name: swap_vouchers swap_vouchers_swap_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.swap_vouchers
    ADD CONSTRAINT swap_vouchers_swap_id_fkey FOREIGN KEY (swap_id) REFERENCES public.swap_requests(swap_id);


--
-- Name: transaction_splits transaction_splits_credited_account_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.transaction_splits
    ADD CONSTRAINT transaction_splits_credited_account_fkey FOREIGN KEY (credited_account) REFERENCES public.ledger_accounts(account_id);


--
-- Name: transaction_splits transaction_splits_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.transaction_splits
    ADD CONSTRAINT transaction_splits_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.transactions(transaction_id);


--
-- Name: users users_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vouchmorphn_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(role_id);


--
-- Name: DATABASE swap_system_bw; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON DATABASE swap_system_bw TO swap_admin;
GRANT ALL ON DATABASE swap_system_bw TO vouchmorphn_user;
GRANT CONNECT ON DATABASE swap_system_bw TO sandbox_user;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;
GRANT USAGE ON SCHEMA public TO vouchmorphn_user;


--
-- Name: FUNCTION armor(bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.armor(bytea) TO vouchmorphn_user;


--
-- Name: FUNCTION armor(bytea, text[], text[]); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.armor(bytea, text[], text[]) TO vouchmorphn_user;


--
-- Name: FUNCTION crypt(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.crypt(text, text) TO vouchmorphn_user;


--
-- Name: FUNCTION dearmor(text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.dearmor(text) TO vouchmorphn_user;


--
-- Name: FUNCTION decrypt(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.decrypt(bytea, bytea, text) TO vouchmorphn_user;


--
-- Name: FUNCTION decrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.decrypt_iv(bytea, bytea, bytea, text) TO vouchmorphn_user;


--
-- Name: FUNCTION digest(bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.digest(bytea, text) TO vouchmorphn_user;


--
-- Name: FUNCTION digest(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.digest(text, text) TO vouchmorphn_user;


--
-- Name: FUNCTION encrypt(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.encrypt(bytea, bytea, text) TO vouchmorphn_user;


--
-- Name: FUNCTION encrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.encrypt_iv(bytea, bytea, bytea, text) TO vouchmorphn_user;


--
-- Name: FUNCTION fn_update_timestamp(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_update_timestamp() TO vouchmorphn_user;


--
-- Name: FUNCTION gen_random_bytes(integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gen_random_bytes(integer) TO vouchmorphn_user;


--
-- Name: FUNCTION gen_random_uuid(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gen_random_uuid() TO vouchmorphn_user;


--
-- Name: FUNCTION gen_salt(text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gen_salt(text) TO vouchmorphn_user;


--
-- Name: FUNCTION gen_salt(text, integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gen_salt(text, integer) TO vouchmorphn_user;


--
-- Name: FUNCTION hmac(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.hmac(bytea, bytea, text) TO vouchmorphn_user;


--
-- Name: FUNCTION hmac(text, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.hmac(text, text, text) TO vouchmorphn_user;


--
-- Name: FUNCTION load_participants_from_json(json_file_path text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.load_participants_from_json(json_file_path text) TO vouchmorphn_user;


--
-- Name: FUNCTION pgp_armor_headers(text, OUT key text, OUT value text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_armor_headers(text, OUT key text, OUT value text) TO vouchmorphn_user;


--
-- Name: FUNCTION pgp_key_id(bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_key_id(bytea) TO vouchmorphn_user;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt(bytea, bytea) TO vouchmorphn_user;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt(bytea, bytea, text) TO vouchmorphn_user;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt(bytea, bytea, text, text) TO vouchmorphn_user;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea) TO vouchmorphn_user;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea, text) TO vouchmorphn_user;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO vouchmorphn_user;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_encrypt(text, bytea) TO vouchmorphn_user;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_encrypt(text, bytea, text) TO vouchmorphn_user;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_encrypt_bytea(bytea, bytea) TO vouchmorphn_user;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_encrypt_bytea(bytea, bytea, text) TO vouchmorphn_user;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_decrypt(bytea, text) TO vouchmorphn_user;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_decrypt(bytea, text, text) TO vouchmorphn_user;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_decrypt_bytea(bytea, text) TO vouchmorphn_user;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_decrypt_bytea(bytea, text, text) TO vouchmorphn_user;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_encrypt(text, text) TO vouchmorphn_user;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_encrypt(text, text, text) TO vouchmorphn_user;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_encrypt_bytea(bytea, text) TO vouchmorphn_user;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_encrypt_bytea(bytea, text, text) TO vouchmorphn_user;


--
-- Name: TABLE api_message_logs; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.api_message_logs TO PUBLIC;
GRANT ALL ON TABLE public.api_message_logs TO vouchmorphn_user;


--
-- Name: SEQUENCE api_message_logs_log_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.api_message_logs_log_id_seq TO PUBLIC;
GRANT ALL ON SEQUENCE public.api_message_logs_log_id_seq TO vouchmorphn_user;


--
-- Name: TABLE cashout_authorizations; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.cashout_authorizations TO PUBLIC;
GRANT ALL ON TABLE public.cashout_authorizations TO vouchmorphn_user;


--
-- Name: SEQUENCE cashout_authorizations_auth_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.cashout_authorizations_auth_id_seq TO PUBLIC;
GRANT ALL ON SEQUENCE public.cashout_authorizations_auth_id_seq TO vouchmorphn_user;


--
-- Name: TABLE deposit_transactions; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.deposit_transactions TO PUBLIC;
GRANT ALL ON TABLE public.deposit_transactions TO vouchmorphn_user;


--
-- Name: SEQUENCE deposit_transactions_deposit_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.deposit_transactions_deposit_id_seq TO PUBLIC;
GRANT ALL ON SEQUENCE public.deposit_transactions_deposit_id_seq TO vouchmorphn_user;


--
-- Name: TABLE hold_transactions; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.hold_transactions TO PUBLIC;
GRANT ALL ON TABLE public.hold_transactions TO vouchmorphn_user;


--
-- Name: SEQUENCE hold_transactions_hold_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.hold_transactions_hold_id_seq TO PUBLIC;
GRANT ALL ON SEQUENCE public.hold_transactions_hold_id_seq TO vouchmorphn_user;


--
-- Name: TABLE message_outbox; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.message_outbox TO PUBLIC;
GRANT ALL ON TABLE public.message_outbox TO vouchmorphn_user;


--
-- Name: TABLE participant_fee_overrides; Type: ACL; Schema: public; Owner: vouchmorphn_user
--

GRANT ALL ON TABLE public.participant_fee_overrides TO PUBLIC;


--
-- Name: SEQUENCE participant_fee_overrides_override_id_seq; Type: ACL; Schema: public; Owner: vouchmorphn_user
--

GRANT ALL ON SEQUENCE public.participant_fee_overrides_override_id_seq TO PUBLIC;


--
-- Name: TABLE participants; Type: ACL; Schema: public; Owner: vouchmorphn_user
--

GRANT ALL ON TABLE public.participants TO PUBLIC;


--
-- Name: SEQUENCE participants_participant_id_seq; Type: ACL; Schema: public; Owner: vouchmorphn_user
--

GRANT ALL ON SEQUENCE public.participants_participant_id_seq TO PUBLIC;


--
-- Name: TABLE send_to_other_transactions; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.send_to_other_transactions TO PUBLIC;
GRANT ALL ON TABLE public.send_to_other_transactions TO vouchmorphn_user;


--
-- Name: SEQUENCE send_to_other_transactions_send_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.send_to_other_transactions_send_id_seq TO PUBLIC;
GRANT ALL ON SEQUENCE public.send_to_other_transactions_send_id_seq TO vouchmorphn_user;


--
-- Name: TABLE settlement_messages; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.settlement_messages TO PUBLIC;
GRANT ALL ON TABLE public.settlement_messages TO vouchmorphn_user;


--
-- Name: SEQUENCE settlement_messages_message_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.settlement_messages_message_id_seq TO PUBLIC;
GRANT ALL ON SEQUENCE public.settlement_messages_message_id_seq TO vouchmorphn_user;


--
-- Name: TABLE settlement_queue; Type: ACL; Schema: public; Owner: vouchmorphn_user
--

GRANT ALL ON TABLE public.settlement_queue TO PUBLIC;


--
-- Name: SEQUENCE settlement_queue_id_seq; Type: ACL; Schema: public; Owner: vouchmorphn_user
--

GRANT ALL ON SEQUENCE public.settlement_queue_id_seq TO PUBLIC;


--
-- Name: TABLE swap_fee_collections; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.swap_fee_collections TO PUBLIC;
GRANT ALL ON TABLE public.swap_fee_collections TO vouchmorphn_user;


--
-- Name: SEQUENCE swap_fee_collections_fee_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.swap_fee_collections_fee_id_seq TO PUBLIC;
GRANT ALL ON SEQUENCE public.swap_fee_collections_fee_id_seq TO vouchmorphn_user;


--
-- Name: TABLE swap_ledgers; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.swap_ledgers TO PUBLIC;
GRANT ALL ON TABLE public.swap_ledgers TO vouchmorphn_user;


--
-- Name: SEQUENCE swap_ledgers_ledger_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.swap_ledgers_ledger_id_seq TO PUBLIC;
GRANT ALL ON SEQUENCE public.swap_ledgers_ledger_id_seq TO vouchmorphn_user;


--
-- Name: TABLE swap_requests; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.swap_requests TO PUBLIC;
GRANT ALL ON TABLE public.swap_requests TO vouchmorphn_user;


--
-- Name: SEQUENCE swap_requests_swap_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.swap_requests_swap_id_seq TO PUBLIC;
GRANT ALL ON SEQUENCE public.swap_requests_swap_id_seq TO vouchmorphn_user;


--
-- Name: TABLE swap_vouchers; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.swap_vouchers TO PUBLIC;
GRANT ALL ON TABLE public.swap_vouchers TO vouchmorphn_user;


--
-- Name: SEQUENCE swap_vouchers_voucher_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.swap_vouchers_voucher_id_seq TO PUBLIC;
GRANT ALL ON SEQUENCE public.swap_vouchers_voucher_id_seq TO vouchmorphn_user;


--
-- Name: TABLE transaction_log_view; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.transaction_log_view TO PUBLIC;
GRANT ALL ON TABLE public.transaction_log_view TO vouchmorphn_user;


--
-- Name: TABLE vouchmorph_notifications; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.vouchmorph_notifications TO PUBLIC;
GRANT ALL ON TABLE public.vouchmorph_notifications TO vouchmorphn_user;


--
-- Name: SEQUENCE vouchmorph_notifications_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.vouchmorph_notifications_id_seq TO PUBLIC;
GRANT ALL ON SEQUENCE public.vouchmorph_notifications_id_seq TO vouchmorphn_user;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO vouchmorphn_user;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO vouchmorphn_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO vouchmorphn_user;


--
-- PostgreSQL database dump complete
--

